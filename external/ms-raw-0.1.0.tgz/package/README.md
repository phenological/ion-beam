# ms-raw

Mass-spec vendor formats to `.ion` or `.mzML`, by reading the binary formats
directly rather than going through a vendor SDK: no `libtimsdata.so`, no
`libbaf2sql_c.so`, no Clearcore2, no MassLynx.

Three modules, one per vendor. **Every module has the same three functions,
taking the same `ConvertOptions` and returning the same types:**

```
open           (input: &Path, options: &ConvertOptions) -> Result<MzML>
convert_to_ion (input: &Path, options:  ConvertOptions) -> Result<Option<Vec<u8>>>
convert_to_mzml(input: &Path, options:  ConvertOptions) -> Result<Option<Vec<u8>>>
```

`open` hands back ionic's `MzML` — the one in-memory representation every
vendor reaches — so a caller can inspect or edit a run before writing it.

| module | input | notes |
|---|---|---|
| `bruker` | `.d` directory | TSF, TDF and BAF; the format is auto-detected |
| `sciex` | `.wiff` + its `.wiff.scan` | one `.wiff` can hold several samples |
| `waters` | `.raw` directory | |

`output: Some(path)` writes the file and returns `None`. `output: None`
returns the encoded bytes as `Vec<u8>`.

There is **one** `ConvertOptions`, shared by all three modules:

| field | meaning | used by |
|---|---|---|
| `output` | file to write; `None` returns bytes | all |
| `select` | which samples (SCIEX) or functions (Waters) to convert; empty takes all | sciex, waters |
| `compression` | whole-file compression of the `.mzML`: `None` / `Gzip` / `Zstd` | all |
| `zlib` | compress the binary arrays inside the mzML | sciex, waters |
| `zstd_level` | 1-19, when `compression` is `Zstd` | sciex, waters |
| `storage` | where the `.ion` encoder buffers: `Memory` or `Disk` | bruker |
| `combine_mobility_scans` | TDF only: sum the ion mobility scans of each frame into one spectrum, as msconvert does with `combineIonMobilitySpectra`; off by default | bruker |

A module ignores the fields that do not apply to it. `ConvertOptions`
implements `Default`, so `..Default::default()` always works.

`ms_raw` also re-exports what you need to work with the result, so ionic is
not a required direct dependency:

```rust
use ms_raw::{ConvertOptions, MzML, Storage};
use ms_raw::{bin_to_mzml, parse_mzml};
```

## The six calls

```rust
use ms_raw::{bruker, sciex, waters, ConvertOptions};
use std::path::Path;

// 1. Bruker -> .ion
bruker::convert_to_ion(
    Path::new("/data/sample.d"),
    ConvertOptions { output: Some("/out/sample.ion".into()), ..Default::default() },
)?;

// 2. Bruker -> .mzML
bruker::convert_to_mzml(
    Path::new("/data/sample.d"),
    ConvertOptions { output: Some("/out/sample.mzML".into()), ..Default::default() },
)?;

// 3. SCIEX -> .ion
sciex::convert_to_ion(
    Path::new("/data/sample.wiff"),
    ConvertOptions { output: Some("/out/sample.ion".into()), ..Default::default() },
)?;

// 4. SCIEX -> .mzML   (second sample of the .wiff)
sciex::convert_to_mzml(
    Path::new("/data/sample.wiff"),
    ConvertOptions {
        output: Some("/out/sample.mzML".into()),
        select: vec![2],
        ..Default::default()
    },
)?;

// 5. Waters -> .ion
waters::convert_to_ion(
    Path::new("/data/sample.raw"),
    ConvertOptions { output: Some("/out/sample.ion".into()), ..Default::default() },
)?;

// 6. Waters -> .mzML
waters::convert_to_mzml(
    Path::new("/data/sample.raw"),
    ConvertOptions { output: Some("/out/sample.mzML".into()), ..Default::default() },
)?;
```

## Reading into memory

`open` returns ionic's `MzML` from any vendor, so the same code works on
all three:

```rust
use ms_raw::{bruker, sciex, waters, ConvertOptions, MzML};

let options = ConvertOptions::default();
let a: MzML = bruker::open(Path::new("/data/sample.d"), &options)?;
let b: MzML = sciex::open(Path::new("/data/sample.wiff"), &options)?;
let c: MzML = waters::open(Path::new("/data/sample.raw"), &options)?;
```

`open` loads the whole run into memory. That is fine for SCIEX and Waters,
but a Bruker profile acquisition decodes to far more than it occupies on
disk — one 205 MB BAF file becomes about 19 GB, because m/z is computed per
bin rather than stored. Use `convert_to_ion` for those: it streams one
spectrum at a time and never holds the run.

## Bytes instead of a file

Leave `output` as `None` and the encoded file comes back as `Vec<u8>`. This
works the same way in all three modules.

```rust
let bytes = bruker::convert_to_ion(
    Path::new("/data/sample.d"),
    ConvertOptions::default(),
)?
.expect("no output path was given");
```

That holds the whole file in memory — hundreds of MB for a real
acquisition — so pass a path when the destination is a file.

## Two things to know

**Prefer `.ion` for Bruker.** `convert_to_mzml` builds the whole run in
memory and writes XML text: one real BAF acquisition came out at 24 GB in
7 minutes, against 245 MB in 29 s for the same data as `.ion`. Profile
spectra carry ~400 000 points each, and XML stores every one as digits.

**BAF needs `analysis.sqlite` to already exist inside the `.d`.** Only
Bruker's SDK can build that cache, and this reader does not use the SDK, so
a `.d` that has never been opened by Bruker software fails with a clear
error. TSF and TDF have no such requirement.

> **Warning — compare arrays, not bytes.**
>
> On one BAF acquisition (10 728 spectra, 10 187 573 peaks) our output has the
> same peak counts, the same retention times and bit-exact intensities as both
> msconvert and `ms-bruker-lib`, which read the same run through Bruker's
> `libbaf2sql_c.so`. Only m/z differs, by at most **4 ulp (9.1e-13 Da)**: we
> compute it in Rust through LLVM, they compute it in the vendor's C++, and the
> two round `sqrt`, `exp` and the polynomial to neighbouring f64 values. That is
> 9 orders of magnitude below a peak width.
>
> The files are still not byte-identical, and the byte count is meaningless: a
> 200-byte provenance difference (the converter's name and version) made 99.4 %
> of the bytes differ, because `.ion` payload is zstd-compressed in blocks and
> one early byte shifts every block after it. `tests/baf_golden.rs` pins the
> m/z gap at 8 ulps against msconvert's own numbers.

## Building

```sh
cargo build --release
cargo test
BRUKER_FIXTURES=data/raw cargo test --release --test golden_values
```

## WebAssembly

The Bruker parser also compiles to a browser module. `convert_to_ion`
takes the files of a `.d` folder as bytes and returns the `.ion` bytes, so a
page can convert an acquisition with no server. Every reader works on a
`Folder`: `DiskFolder` on native, `MemoryFolder` in wasm, so the parser
itself has one code path.

SQLite is compiled from C for the wasm target, so the build needs a clang
that can target wasm. On macOS:

```sh
brew install llvm binaryen
cargo install wasm-pack
CC_wasm32_unknown_unknown=/opt/homebrew/opt/llvm/bin/clang \
AR_wasm32_unknown_unknown=/opt/homebrew/opt/llvm/bin/llvm-ar \
wasm-pack build --release --target web --out-dir pkg
```

That writes `pkg/ms_raw.js`, `pkg/ms_raw_bg.wasm` and the TypeScript types.
To install it in a JavaScript project, pack it and install the archive:

```sh
cd pkg && npm pack && mv ms-raw-0.1.0.tgz ..
cd /path/to/your-app && npm install /path/to/ms-raw/ms-raw-0.1.0.tgz
```

`web/index.html` is a small page that uses the package:

```js
import init, { convert_to_ion } from "./pkg/ms_raw.js";
await init();
const ion = convert_to_ion("sample.d", ["analysis.tsf", "analysis.tsf_bin"], [tsfBytes, tsfBinBytes]);
```

Paths are relative to the `.d` folder, with `/` for files inside a
subfolder such as `sample.m/submethods.xml`.

In the browser ionic compresses the `.ion` blocks with `ruzstd`, a pure
Rust zstd encoder with one level close to zstd 1, where the native build
uses the C library at level 9. The arrays are identical, the file is larger
and the conversion is slower.

## Documentation

* [`docs/README.md`](docs/README.md) — **start here.** What works, how each
  format was verified, where the test data is, how to run the tests, and
  every known gap.
* [`src/bruker/README.md`](src/bruker/README.md) — how Bruker's m/z
  calibration works and how this reader computes it
* `docs/how-to-crack-details.md` — the method used to reverse-engineer the
  Bruker binary formats
* `docs/implementing-tdf-and-baf.md` — record of how TSF, TDF and BAF were
  done, with verification numbers and the untested edges
* `docs/status-baf.md` — BAF in full: array ids, the VLI2 codec, the
  calibration blob, disassembly addresses
* `docs/tdf-format.md` — TDF container notes
