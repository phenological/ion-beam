export declare function init(): Promise<void>;
export * from "./utilities/api";
export { SampleFile } from "./utilities/sampleFile";
export { encodeTargetIds, unpackTargets } from "./utilities/pack";
export { ContainmentCache, type ByteRange } from "./utilities/containmentCache";
//# sourceMappingURL=index-node.d.ts.map