export interface ByteRange {
    offset: bigint;
    length: bigint;
}
export declare class ContainmentCache {
    private cached;
    constructor();
    add(range: ByteRange, bytes: Uint8Array): void;
    read(offset: bigint, length: bigint): Uint8Array | null;
    has(range: ByteRange): boolean;
    missing(ranges: ByteRange[]): ByteRange[];
    clear(): void;
    pin(): void;
    dropUnpinned(): void;
    bytes(): number;
}
//# sourceMappingURL=containmentCache.d.ts.map