type FreeCell<H> = {
    handle: H | null;
    free: (h: H) => void;
};
declare class HandleRegistry<H> {
    private readonly registry;
    constructor();
    register(owner: object, handle: H, free: (h: H) => void): FreeCell<H>;
    release(owner: object, cell: FreeCell<H>): void;
}
export declare const fileHandleRegistry: HandleRegistry<unknown>;
export {};
//# sourceMappingURL=handleRegistry.d.ts.map