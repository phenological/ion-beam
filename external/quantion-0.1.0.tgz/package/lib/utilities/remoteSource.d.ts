import { ContainmentCache } from "./containmentCache";
export type ByteRangeResult = {
    offset: bigint;
    length: bigint;
};
export type RemoteSource = {
    url: string;
    cache: ContainmentCache;
    total: bigint;
    multipart: boolean | null;
};
export declare const HEADER_BYTES = 1024n;
export declare function newRemoteSource(url: string): RemoteSource;
export declare function fetchRange(url: string, range: ByteRangeResult): Promise<Uint8Array>;
export declare function coalesceRanges(ranges: ByteRangeResult[], gap?: bigint): ByteRangeResult[];
/**
 * Split a `multipart/byteranges` body into the parts it carries. Each part is
 * located by its own `Content-Range`, so the parts need not arrive in the order
 * they were asked for. Returns null when the body is not parseable as multipart.
 */
export declare function splitByteRanges(body: Uint8Array, boundary: string): {
    offset: bigint;
    bytes: Uint8Array;
}[] | null;
/**
 * Ask for every range in a single request. Resolves to null when the server
 * does not honour multi-range requests, which object stores such as S3, GCS and
 * R2 signal by answering 200 with the whole object; the body is discarded
 * unread in that case so nothing extra is downloaded.
 */
export declare function fetchRanges(url: string, ranges: ByteRangeResult[]): Promise<Uint8Array[] | null>;
export declare function fetchRangeParts(url: string, range: ByteRangeResult): Promise<Uint8Array>;
export declare function prefetchRanges(source: RemoteSource, ranges: ByteRangeResult[]): Promise<void>;
export declare function fetchHeader(source: RemoteSource): Promise<Uint8Array>;
//# sourceMappingURL=remoteSource.d.ts.map