import type { BinaryInput } from "../types/types";
export declare function camelizeKeys<T>(value: T): T;
export declare function parseAndCamelize<T>(json: string): T;
export declare function toCores(cores: unknown): number;
export declare function toUint8(input: BinaryInput): Uint8Array;
//# sourceMappingURL=shared.d.ts.map