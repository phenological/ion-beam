import type { IonImage } from "../types/types";
export declare function readIonImage(buffer: ArrayBuffer): IonImage;
//# sourceMappingURL=imageBridge.d.ts.map