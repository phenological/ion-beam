export declare function readRecords(buffer: ArrayBuffer): Record<string, unknown>[];
//# sourceMappingURL=recordBridge.d.ts.map