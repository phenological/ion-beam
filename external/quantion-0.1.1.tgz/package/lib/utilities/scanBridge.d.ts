import type { CentroidScan } from "../types/types";
export declare function readScans(buffer: ArrayBuffer): CentroidScan[];
//# sourceMappingURL=scanBridge.d.ts.map