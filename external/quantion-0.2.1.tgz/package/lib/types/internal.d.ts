export interface ModelEntry {
    key: string;
    value: string;
}
export interface ByteRange {
    offset: number;
    length: number;
}
//# sourceMappingURL=internal.d.ts.map