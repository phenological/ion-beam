import type { Backend } from "./backend";
import { SampleFile } from "./sampleFile";
import { Model } from "./model";
import { WarpModel } from "./warpModel";
import type { AnnotateFeaturesOptions, FeatureAnnotation, CalculateBaselineOptions, BinaryInput, DataXY, DrawPeaksOptions, CalculateEicOptions, Feature, FindFeaturesOptions, FindPeaksOptions, FindTargetsOptions, FindTransitionsOptions, FitPeakOptions, GetPeakOptions, GetScanMetadataOptions, GetScansOptions, IonImage, GetIonImageOptions, IonInput, DeisotopeFeaturesOptions, MatchFeaturesOptions, NoiseLevel, ParseIonOptions, Peak, PeakParameters, Scan, ScanParam, ScanQuery, Target, Transition, WriteIonOptions, WriteMzmlOptions } from "../types/types";
export declare function setBackend(backend: Backend): void;
export declare function setInitPromise(promise: Promise<void>): void;
/**
 * parseIon · Files
 *
 * Open an Ionic file (.ion) from a path, a URL or bytes. Paths and URLs are read lazily: only the bytes a query needs are fetched.
 *
 * **Warning:** The sample is freed by the library once it is no longer used, so dispose is not needed in normal use. When processing many samples, dispose each one after using it, so its memory is freed right away instead of piling up.
 *
 * @param source - Where the file is: a path, an http(s) URL, or raw bytes.
 * @param options - Optional settings: `maxCacheSize` = 0. See {@link https://phenological.github.io/quantion/?language=js#ParseIonOptions | ParseIonOptions}.
 * @returns The opened sample.
 * @see {@link https://phenological.github.io/quantion/?language=js#parse_ion | Documentation}
 */
export declare function parseIon(source: IonInput, options?: ParseIonOptions): Promise<SampleFile>;
/**
 * parseMzml · Files
 *
 * Open an mzML file from a path or bytes. It is always loaded fully into memory. URLs are refused.
 *
 * **Warning:** The sample is freed by the library once it is no longer used, so dispose is not needed in normal use. When processing many samples, dispose each one after using it, so its memory is freed right away instead of piling up.
 *
 * @param source - Where the file is: a path or raw bytes.
 * @returns The loaded sample.
 * @see {@link https://phenological.github.io/quantion/?language=js#parse_mzml | Documentation}
 */
export declare function parseMzml(source: string | BinaryInput): Promise<SampleFile>;
/**
 * writeIon · Files
 *
 * Write a sample as an Ionic file (.ion). With no out, it returns the bytes. A path writes a file; a URL uploads it in one PUT request.
 *
 * @param file - The sample to write.
 * @param options - Optional settings: `out` = undefined, `overwrite` = false, `level` = 12, `f32Compress` = false, `blockSize` = 8, `mzWindow` = 20, `headers` = []. See {@link https://phenological.github.io/quantion/?language=js#WriteIonOptions | WriteIonOptions}.
 * @returns The bytes when out is left out; nothing when it is written or uploaded.
 * @see {@link https://phenological.github.io/quantion/?language=js#write_ion | Documentation}
 */
export declare function writeIon(file: SampleFile, options?: WriteIonOptions): Promise<Uint8Array | undefined>;
/**
 * writeMzml · Files
 *
 * Write a sample as mzML. With no out, it returns the bytes. Only a path is allowed, no URL.
 *
 * @param file - The sample to write.
 * @param options - Optional settings: `out` = undefined, `overwrite` = false. See {@link https://phenological.github.io/quantion/?language=js#WriteMzmlOptions | WriteMzmlOptions}.
 * @returns The bytes when out is left out; nothing when it is written.
 * @see {@link https://phenological.github.io/quantion/?language=js#write_mzml | Documentation}
 */
export declare function writeMzml(file: SampleFile, options?: WriteMzmlOptions): Promise<Uint8Array | undefined>;
/**
 * loadModel · Models
 *
 * Load an ONNX model from a path, a URL or bytes, and read the keys and values stored in it.
 *
 * @param source - Where the model is: a path, an http(s) URL, or raw bytes.
 * @returns The model, with get_keys(), get_values() and get_value(key).
 * @see {@link https://phenological.github.io/quantion/?language=js#load_model | Documentation}
 */
export declare function loadModel(source: IonInput): Promise<Model>;
/**
 * loadWarp · Models
 *
 * Make a retention-time warp model from a loaded model.
 *
 * @param model - A model from load_model that holds a warp.
 * @returns The warp model.
 * @see {@link https://phenological.github.io/quantion/?language=js#load_warp | Documentation}
 */
export declare function loadWarp(model: Model): WarpModel;
/**
 * getScans · Files
 *
 * Read scans by retention time, by precursor m/z, or by both. Ranges return every scan inside them; when rt or mz is one value, you get the closest scan, as a list of one.
 *
 * @param file - The sample to read, from parse_ion or parse_mzml.
 * @param query.rt - Which scans by retention time: a range or one value. Optional when mz is given. Each FromTo has `from`, `to`. See {@link https://phenological.github.io/quantion/?language=js#FromTo | FromTo}.
 *   Example: `const window: FromTo = { from: 1.0, to: 2.5 };`
 * @param query.mz - Which scans by precursor m/z: a range or one value. Give rt, mz or both. Each FromTo has `from`, `to`. See {@link https://phenological.github.io/quantion/?language=js#FromTo | FromTo}.
 *   Example: `const window: FromTo = { from: 1.0, to: 2.5 };`
 * @param options - Optional settings: `level` = 1, `timeUnit` = "MINUTES", `arrays` = { key: "mz", accession: "MS:1000514" }, { key: "intensity", accession: "MS:1000515" }. See {@link https://phenological.github.io/quantion/?language=js#GetScansOptions | GetScansOptions}.
 * @returns The scans found, in rt order.
 * @see {@link https://phenological.github.io/quantion/?language=js#get_scans | Documentation}
 */
export declare function getScans(file: SampleFile, query: ScanQuery, options?: GetScansOptions): Promise<Scan[]>;
/**
 * getScanMetadata · Metadata
 *
 * Read the attributes, cvParams and userParams of one scan, one row each, parents before children. Find the scan with get_scans, then pass its index.
 *
 * @param file - The sample to read, from parse_ion or parse_mzml.
 * @param index - Position of the scan in the spectrum list, from 0: the index of a scan from get_scans.
 * @param options - Optional settings: `tags` = []. See {@link https://phenological.github.io/quantion/?language=js#GetScanMetadataOptions | GetScanMetadataOptions}.
 * @returns One row per attribute or param, in the order of the mzML tree. Values are text. A field the file does not give is missing: None in Rust and Python, null in JS, NA in R.
 * @see {@link https://phenological.github.io/quantion/?language=js#get_scan_metadata | Documentation}
 */
export declare function getScanMetadata(file: SampleFile, index: number, options?: GetScanMetadataOptions): Promise<ScanParam[]>;
/**
 * calculateEic · Files
 *
 * Extract the ion chromatogram of one m/z.
 *
 * @param file - The sample to read, from parse_ion or parse_mzml.
 * @param mz - The m/z to extract (Da).
 * @param options - Optional settings: `from` = 0, `to` = Infinity, `ppmTolerance` = 20, `mzTolerance` = 0.005, `timeUnit` = "MINUTES". See {@link https://phenological.github.io/quantion/?language=js#CalculateEicOptions | CalculateEicOptions}.
 * @returns The chromatogram: x = retention times, y = summed intensities.
 * @see {@link https://phenological.github.io/quantion/?language=js#calculate_eic | Documentation}
 */
export declare function calculateEic(file: SampleFile, mz: number, options?: CalculateEicOptions): Promise<DataXY>;
/**
 * getIonImage · Files
 *
 * Build an imaging map of one m/z: summed intensity at each x, y position.
 *
 * **Warning:** Only Ionic files (.ion). The sample must come from parse_ion; a sample from parse_mzml gives an invalid_argument error.
 *
 * @param file - The sample to read. Must come from parse_ion.
 * @param mz - The m/z to map (Da).
 * @param options - Optional settings: `tolerance` = 0.125, `level` = 1, `onProgress` = undefined. See {@link https://phenological.github.io/quantion/?language=js#GetIonImageOptions | GetIonImageOptions}.
 * @returns The image.
 * @see {@link https://phenological.github.io/quantion/?language=js#get_ion_image | Documentation}
 */
export declare function getIonImage(file: SampleFile, mz: number, options?: GetIonImageOptions): Promise<IonImage>;
/**
 * findPeaks · Traces
 *
 * Find every peak in one trace.
 *
 * @param x - Retention times, ascending. At least 3 points.
 * @param y - Intensities, same length as x.
 * @param options - Optional settings: `minIntegral` = off, `minIntensity` = 500, `minPeakWidthPoints` = 3, `noise` = off, `autoNoise` = true, `autoBaseline` = true, `lambda` = 20, `maxIterations` = 4, `allowOverlap` = false, `minSnr` = 2, `minR2` = 0, `shape` = "EMG", `kernelSize` = 0. See {@link https://phenological.github.io/quantion/?language=js#FindPeaksOptions | FindPeaksOptions}.
 * @returns Every peak that passes the filters.
 * @see {@link https://phenological.github.io/quantion/?language=js#find_peaks | Documentation}
 */
export declare function findPeaks(x: Float64Array, y: Float64Array, options?: FindPeaksOptions): Peak[];
/**
 * getPeak · Traces
 *
 * Find the one peak near rt. With a range, only rt ± range is searched; without one, the whole trace is searched and the peak is chosen by its size and its distance to rt.
 *
 * @param x - Retention times, ascending. At least 3 points.
 * @param y - Intensities, same length as x.
 * @param rt - Expected retention time of the peak.
 * @param options - Optional settings: `range` = 0, `findPeaks`. See {@link https://phenological.github.io/quantion/?language=js#GetPeakOptions | GetPeakOptions}.
 * @returns The best peak near rt. No peak gives a Peak with every field 0.
 * @see {@link https://phenological.github.io/quantion/?language=js#get_peak | Documentation}
 */
export declare function getPeak(x: Float64Array, y: Float64Array, rt: number, options?: GetPeakOptions): Peak;
/**
 * fitPeak · Traces
 *
 * Fit a Gaussian or EMG curve to the peak near rt. rt says which peak; its apex intensity is the starting point unless you force one.
 *
 * @param x - Retention times, ascending. At least 3 points.
 * @param y - Intensities, same length as x.
 * @param rt - Expected retention time of the peak.
 * @param options - Optional settings: `shape` = "EMG", `intensity` = 0. See {@link https://phenological.github.io/quantion/?language=js#FitPeakOptions | FitPeakOptions}.
 * @returns The fitted curve, or none when no peak is found or the fit fails.
 * @see {@link https://phenological.github.io/quantion/?language=js#fit_peak | Documentation}
 */
export declare function fitPeak(x: Float64Array, y: Float64Array, rt: number, options?: FitPeakOptions): PeakParameters | null;
/**
 * drawPeaks · Traces
 *
 * Simulate a chromatogram from one or more peak shapes. Every peak is drawn into the same chromatogram; where they overlap, intensities add up. No real data is needed.
 *
 * @param params - The peaks to draw, one PeakParameters per peak. Each PeakParameters has `height`, `center`, `fwhm`, `tail`, `r2`. See {@link https://phenological.github.io/quantion/?language=js#PeakParameters | PeakParameters}.
 *   Example: `const peak: PeakParameters = { height: 9800, center: 2.38, fwhm: 0.021, tail: 0.006 };`
 * @param options - Optional settings: `from` = 0, `to` = 0, `points` = 1000. See {@link https://phenological.github.io/quantion/?language=js#DrawPeaksOptions | DrawPeaksOptions}.
 * @returns The simulated chromatogram: x = retention times, y = summed intensities.
 * @see {@link https://phenological.github.io/quantion/?language=js#draw_peaks | Documentation}
 */
export declare function drawPeaks(params: PeakParameters[], options?: DrawPeaksOptions): DataXY;
/**
 * findNoiseLevel · Traces
 *
 * Estimate the noise level of a signal.
 *
 * @param y - Intensities.
 * @returns The noise intensity and the window width it came from.
 * @see {@link https://phenological.github.io/quantion/?language=js#find_noise_level | Documentation}
 */
export declare function findNoiseLevel(y: Float64Array | Float32Array): NoiseLevel;
/**
 * calculateBaseline · Traces
 *
 * Estimate a signal's baseline with airPLS.
 *
 * @param y - Intensities.
 * @param options - Optional settings: `lambda` = 20, `maxIterations` = 4. See {@link https://phenological.github.io/quantion/?language=js#CalculateBaselineOptions | CalculateBaselineOptions}.
 * @returns The baseline, same length as y.
 * @see {@link https://phenological.github.io/quantion/?language=js#calculate_baseline | Documentation}
 */
export declare function calculateBaseline(y: Float64Array, options?: CalculateBaselineOptions): Float64Array;
/**
 * findTargets · Targeted
 *
 * For each target, build its EIC at mz and find its peak near rt ± range.
 *
 * @param file - The sample to read, from parse_ion or parse_mzml.
 * @param targets - What to look for. A target without range searches its whole EIC. Each Target has `id`, `mz`, `rt`, `range`. See {@link https://phenological.github.io/quantion/?language=js#Target | Target}.
 *   Example: `const target: Target = { id: "compound_1", mz: 260.103, rt: 2.383, range: 0.05 };`
 * @param options - Optional settings: `eic`, `findPeaks`, `threads` = 1. See {@link https://phenological.github.io/quantion/?language=js#FindTargetsOptions | FindTargetsOptions}.
 * @returns One Peak per target, in the same order. A target with no peak gets a Peak with every field 0.
 * @see {@link https://phenological.github.io/quantion/?language=js#find_targets | Documentation}
 */
export declare function findTargets(file: SampleFile, targets: Target[], options?: FindTargetsOptions): Promise<Peak[]>;
/**
 * findTransitions · Targeted
 *
 * For each SRM transition, take the stored chromatogram whose precursor (Q1) and product (Q3) are both within 0.005 m/z, and find its peak near rt ± range.
 *
 * **Warning:** Needs the whole file. A sample opened from a URL gives a remote_file error; open it from a path or bytes.
 *
 * @param file - The sample to read, from parse_ion or parse_mzml.
 * @param targets - The transitions. Each Transition has `id`, `precursor`, `product`, `rt`, `range`. See {@link https://phenological.github.io/quantion/?language=js#Transition | Transition}.
 *   Example: `const transition: Transition = { id: "compound_1", precursor: 89.04768, product: 89.04768, rt: 2.385, range: 0.1 };`
 * @param options - Optional settings: `findPeaks`, `threads` = 1. See {@link https://phenological.github.io/quantion/?language=js#FindTransitionsOptions | FindTransitionsOptions}.
 * @returns One Peak per transition, in the same order. No match gives a Peak with every field 0.
 * @see {@link https://phenological.github.io/quantion/?language=js#find_transitions | Documentation}
 */
export declare function findTransitions(file: SampleFile, targets: Transition[], options?: FindTransitionsOptions): Peak[];
/**
 * findFeatures · Untargeted
 *
 * Untargeted: find every feature in one file by scanning an m/z grid.
 *
 * @param file - The sample to read, from parse_ion or parse_mzml.
 * @param options - Optional settings: `eic`, `grid`, `findPeaks`, `threads` = 1. See {@link https://phenological.github.io/quantion/?language=js#FindFeaturesOptions | FindFeaturesOptions}.
 * @returns Every feature found, without frequency.
 * @see {@link https://phenological.github.io/quantion/?language=js#find_features | Documentation}
 */
export declare function findFeatures(file: SampleFile, options?: FindFeaturesOptions): Promise<Feature[]>;
/**
 * matchFeatures · Untargeted
 *
 * Untargeted across samples: find features in every file of a folder and match them. Values are medians over the samples where a feature was found.
 *
 * @param directory - Folder with the Ionic (.ion) or mzML files.
 * @param options - Optional settings: `eic`, `grid`, `grouping`, `findPeaks`, `threads` = 1. See {@link https://phenological.github.io/quantion/?language=js#MatchFeaturesOptions | MatchFeaturesOptions}.
 * @returns One Feature per matched feature; frequency is the fraction of samples (0–1).
 * @see {@link https://phenological.github.io/quantion/?language=js#match_features | Documentation}
 */
export declare function matchFeatures(directory: string, options?: MatchFeaturesOptions): Feature[];
/**
 * deisotopeFeatures · Untargeted
 *
 * Remove 13C isotope peaks from a feature list, keeping the monoisotopic peak (M) of each compound. A feature is an isotope when it sits 1.00335/charge above the previous peak (charge = 1 or 2), has the same rt as M, and its intensity is not too high: M+1 at most M × mz × charge / 12 × 0.0108157.
 *
 * @param features - The features to clean, from find_features or match_features.
 * @param options - Optional settings: `rtTolerance` = 0.02, `mzTolerance` = 0.005. See {@link https://phenological.github.io/quantion/?language=js#DeisotopeFeaturesOptions | DeisotopeFeaturesOptions}.
 * @returns The features that are not isotopes, sorted by m/z.
 * @see {@link https://phenological.github.io/quantion/?language=js#deisotope_features | Documentation}
 */
export declare function deisotopeFeatures(features: Feature[], options?: DeisotopeFeaturesOptions): Feature[];
/**
 * annotateFeatures · Untargeted
 *
 * Name features from their MS2 spectra. For each feature, every sample gives its closest MS2 scan; a spectrum model turns it into a vector, which is compared with the library spectra of the same precursor m/z. The library and the model are read from a path or a URL; over a URL only the bytes needed are fetched, in one batch per source.
 *
 * **Warning:** The model sets how spectra are read through its metadata keys: max_peaks, max_mz, intensity_scale (SQRT or NONE), vector_accession (the library array that holds the vectors), and compound, id, database and label (the library params that name each spectrum). A missing or invalid key gives an error.
 *
 * @param files - The samples, from parse_ion or parse_mzml. Must not be empty.
 * @param features - The features to name: mz and rt each. find_features and match_features output works as is. Empty gives an empty result.
 * @param options - Optional settings: `library` = "https://github.com/josoriom/cipher/releases/latest/download/library_positive.ion", `model` = "https://github.com/josoriom/cipher/releases/latest/download/model.onnx", `matches` = 3, `ppmTolerance` = 20, `mzTolerance` = 0.005, `rtRange` = 0.3, `minRelativeIntensity` = 0.02. See {@link https://phenological.github.io/quantion/?language=js#AnnotateFeaturesOptions | AnnotateFeaturesOptions}.
 * @returns One FeatureAnnotation per feature, in the same order.
 * @see {@link https://phenological.github.io/quantion/?language=js#annotate_features | Documentation}
 */
export declare function annotateFeatures(files: SampleFile[], features: Array<{
    mz: number;
    rt: number;
}>, options?: AnnotateFeaturesOptions): Promise<FeatureAnnotation[]>;
//# sourceMappingURL=api.d.ts.map