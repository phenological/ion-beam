export declare const ERROR_CODES: {
    readonly invalid_argument: 1;
    readonly missing_argument: 2;
    readonly unknown_option: 3;
    readonly remote_file: 4;
    readonly file_not_found: 5;
    readonly parse_failed: 6;
    readonly model_mismatch: 7;
    readonly file_exists: 8;
    readonly upload_failed: 9;
    readonly internal: 99;
};
/**
 * ErrorKind · Errors
 *
 * What went wrong, as a name and a fixed number code.
 *
 * Fields:
 * - `"invalid_argument"`: A value is out of range or the wrong type.
 * - `"missing_argument"`: A required value is missing.
 * - `"unknown_option"`: An option key that does not exist.
 * - `"remote_file"`: Needs the whole file, but a URL was given.
 * - `"file_not_found"`: The path does not exist.
 * - `"parse_failed"`: The file is not a valid Ionic (.ion), mzML or ONNX file.
 * - `"model_mismatch"`: The model has no warp, or a target is not in it.
 * - `"file_exists"`: The output file exists and overwrite is false.
 * - `"upload_failed"`: The upload was rejected, with the HTTP status.
 * - `"internal"`: A bug in quantion. Please report it.
 * @see {@link https://phenological.github.io/quantion/?language=js#ErrorKind | Documentation}
 */
export type ErrorKind = keyof typeof ERROR_CODES;
/**
 * QuantionError · Errors
 *
 * The error every function raises, with its kind, code, function, argument and message.
 *
 * Fields:
 * - `kind`: What went wrong.
 * - `code`: Fixed number for the kind.
 * - `function`: Where: the public function that failed.
 * - `argument`: Which input, such as targets[3].range.
 * - `message`: Why, in plain words. Starts with the function name.
 * @see {@link https://phenological.github.io/quantion/?language=js#QuantionError | Documentation}
 */
export declare class QuantionError extends Error {
    readonly kind: ErrorKind;
    readonly code: number;
    readonly function: string;
    readonly argument: string | undefined;
    constructor(kind: ErrorKind, functionName: string, message: string, argument?: string);
}
export declare function readNativeError(text: string): QuantionError;
export declare function missingArgument(functionName: string, argument: string): QuantionError;
export declare function invalidArgument(functionName: string, argument: string, message: string): QuantionError;
export declare function toQuantionError(error: unknown): unknown;
//# sourceMappingURL=errors.d.ts.map