import type { IonInput } from "../types/types";
export interface PathSource {
    kind: "path";
    path: string;
}
export interface UrlSource {
    kind: "url";
    url: URL;
}
export interface BufferSource {
    kind: "buffer";
    bytes: Uint8Array;
}
export type IonSource = PathSource | UrlSource | BufferSource;
export declare function getIonSource(input: IonInput, caller: string): IonSource;
//# sourceMappingURL=ionSource.d.ts.map