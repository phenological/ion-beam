import type { ModelEntry } from "../types/internal";
export declare abstract class Metadata {
    protected abstract _getMetadata(caller: string): ModelEntry[];
    /**
     * The keys stored in the model file, in file order.
     */
    getKeys(): string[];
    /**
     * The values stored in the model file, in the same order as {@link getKeys}.
     */
    getValues(): string[];
    /**
     * The text stored under `key` in the model file, or `undefined` if it is missing.
     */
    getValue(key: string): string | undefined;
}
//# sourceMappingURL=metadata.d.ts.map