import type { Backend, ModelHandle } from "./backend";
import { Metadata } from "./metadata";
import type { ModelEntry } from "../types/internal";
/**
 * A loaded ONNX model. Load it with {@link loadModel} and read its stored keys and values.
 */
export declare class Model extends Metadata {
    /** @internal */
    _backend: Backend;
    private _cell;
    private metadata;
    constructor(handle: ModelHandle, backend: Backend);
    get _handle(): ModelHandle | null;
    /**
     * dispose · Models
     *
     * Free the memory held by a sample, model or warp model.
     *
     * **Warning:** Not needed in normal use: the library frees a sample, model or warp model by itself once it is no longer used. When processing many samples, dispose each one after using it, so its memory is freed right away instead of piling up.
     * @returns Nothing.
     * @see {@link https://phenological.github.io/quantion/?language=js#dispose | Documentation}
     */
    dispose(): void;
    /** @internal */
    _getMetadata(caller: string): ModelEntry[];
}
//# sourceMappingURL=model.d.ts.map