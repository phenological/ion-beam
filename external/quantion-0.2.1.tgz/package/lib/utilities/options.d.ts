import { PeakShape, TimeUnit } from "../types/types";
import type { AnnotateFeaturesOptions, CalculateBaselineOptions, DeisotopeFeaturesOptions, DrawPeaksOptions, CalculateEicOptions, FindPeaksOptions, FitPeakOptions, GetScanMetadataOptions, GetScansOptions, ScanArray, GridOptions, GroupingOptions, Header, GetIonImageOptions, ParseIonOptions } from "../types/types";
export type Complete<T> = {
    [Key in keyof T]-?: T[Key];
};
export interface TargetSettingsInput {
    eic: Complete<CalculateEicOptions>;
    findPeaks: Complete<FindPeaksOptions>;
    threads: number;
}
export interface TransitionSettingsInput {
    findPeaks: Complete<FindPeaksOptions>;
    threads: number;
}
export interface FeatureSettingsInput {
    eic: Complete<CalculateEicOptions>;
    grid: Complete<GridOptions>;
    findPeaks: Complete<FindPeaksOptions>;
    threads: number;
}
export interface MatchSettingsInput extends FeatureSettingsInput {
    grouping: Complete<GroupingOptions>;
}
export declare const FIND_PEAKS_DEFAULTS: Complete<FindPeaksOptions>;
export declare const EIC_DEFAULTS: Complete<CalculateEicOptions>;
export declare const GRID_DEFAULTS: Complete<GridOptions>;
export declare const GROUPING_DEFAULTS: Complete<GroupingOptions>;
export declare const TARGET_KEYS: string[];
export declare const FEATURE_NUMBER_KEYS: readonly ["mz", "rt", "from", "to", "intensity", "integral", "nPoints"];
export declare const TRANSITION_KEYS: string[];
export declare const PEAK_KEYS: string[];
export declare const RANGE_KEYS: string[];
export declare function checkItems(items: object[], allowed: string[], functionName: string, argument: string): void;
export declare function getRequiredNumber(value: unknown, functionName: string, argument: string): number;
export declare function checkKeys(given: Record<string, unknown>, allowed: readonly string[], functionName: string, path: string): void;
export declare function readFindPeaksOptions(value: unknown, functionName: string, path?: string): Complete<FindPeaksOptions>;
export declare function readEicOptions(value: unknown, functionName: string, path?: string): Complete<CalculateEicOptions>;
export declare function readGridOptions(value: unknown, functionName: string): Complete<GridOptions>;
export declare function readGroupingOptions(value: unknown, functionName: string): Complete<GroupingOptions>;
export declare function readGetPeakOptions(value: unknown, functionName: string): {
    range: number;
    findPeaks: Complete<FindPeaksOptions>;
};
export declare function readFitPeakOptions(value: unknown, functionName: string): Complete<FitPeakOptions>;
export declare function readDrawPeaksOptions(value: unknown, functionName: string): Complete<DrawPeaksOptions>;
export declare function readBaselineOptions(value: unknown, functionName: string): Complete<CalculateBaselineOptions>;
export declare function readDeisotopeFeaturesOptions(value: unknown, functionName: string): Complete<DeisotopeFeaturesOptions>;
export declare function readFindTargetsOptions(value: unknown, functionName: string): TargetSettingsInput;
export declare function readFindTransitionsOptions(value: unknown, functionName: string): TransitionSettingsInput;
export declare function readFindFeaturesOptions(value: unknown, functionName: string): FeatureSettingsInput;
export declare function readMatchFeaturesOptions(value: unknown, functionName: string): MatchSettingsInput;
export declare function hasDefaultScanArrays(arrays: ScanArray[]): boolean;
export declare function getAccessionNumbers(arrays: ScanArray[]): Uint32Array;
export declare function readGetScansOptions(value: unknown, functionName: string): Complete<GetScansOptions>;
export declare const TAG_SEPARATOR = "\u001F";
export declare const SCAN_METADATA_TAGS: readonly ["spectrum", "referenceableParamGroupRef", "spectrumDescription", "scanList", "scan", "scanWindowList", "scanWindow", "precursorList", "precursor", "isolationWindow", "selectedIonList", "selectedIon", "activation", "productList", "product", "binaryDataArrayList", "binaryDataArray"];
export declare function readGetScanMetadataOptions(value: unknown, functionName: string): Complete<GetScanMetadataOptions>;
export declare function readParseIonOptions(value: unknown, functionName: string): Complete<ParseIonOptions>;
export interface WriteIonSettings {
    out: string | null;
    overwrite: boolean;
    level: number;
    f32Compress: boolean;
    blockSize: number;
    mzWindow: number;
    headers: Header[];
}
export declare function readWriteIonOptions(value: unknown, functionName: string): WriteIonSettings;
export declare function readWriteMzmlOptions(value: unknown, functionName: string): {
    out: string | null;
    overwrite: boolean;
};
export declare function readIonImageOptions(value: unknown, functionName: string): Complete<GetIonImageOptions>;
export declare function packHeaders(headers: Header[]): Uint8Array;
export declare function getTimeUnitCode(timeUnit: TimeUnit): number;
export declare function getShapeCode(shape: PeakShape): number;
export declare const DEFAULT_LIBRARY = "https://github.com/josoriom/cipher/releases/latest/download/library_positive.ion";
export declare const DEFAULT_MODEL = "https://github.com/josoriom/cipher/releases/latest/download/model.onnx";
export declare function readAnnotateFeaturesOptions(value: unknown, functionName: string): Complete<AnnotateFeaturesOptions>;
//# sourceMappingURL=options.d.ts.map