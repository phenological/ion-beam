export declare function encodeTargetIds(ids: string[]): {
    packedBytes: Uint8Array;
    offsets: Uint32Array;
    lengths: Uint32Array;
};
//# sourceMappingURL=pack.d.ts.map