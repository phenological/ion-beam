import type { ScanParam } from "../types/types";
export declare function readRecords(buffer: ArrayBuffer): Record<string, unknown>[];
export declare function readScanMetadata(buffer: ArrayBuffer): ScanParam[];
//# sourceMappingURL=recordBridge.d.ts.map