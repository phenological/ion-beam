import type { Backend, FileHandle } from "./backend";
/**
 * SampleFile · Inputs
 *
 * An opened sample from parse_ion or parse_mzml. Free it with dispose when you are done.
 * @see {@link https://phenological.github.io/quantion/?language=js#SampleFile | Documentation}
 */
export declare class SampleFile {
    /** @internal */
    _backend: Backend;
    private _cell;
    constructor(handle: FileHandle, backend: Backend);
    get _handle(): FileHandle | null;
    /**
     * dispose · Models
     *
     * Free the memory held by a sample, model or warp model.
     *
     * **Warning:** Not needed in normal use: the library frees a sample, model or warp model by itself once it is no longer used. When processing many samples, dispose each one after using it, so its memory is freed right away instead of piling up.
     * @returns Nothing.
     * @see {@link https://phenological.github.io/quantion/?language=js#dispose | Documentation}
     */
    dispose(): void;
}
//# sourceMappingURL=sampleFile.d.ts.map