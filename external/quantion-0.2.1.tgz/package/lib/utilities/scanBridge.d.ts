import type { Scan } from "../types/types";
export declare function readScans(buffer: ArrayBuffer): Scan[];
export declare function readScanArrays(buffer: ArrayBuffer, keys: string[]): Scan[];
//# sourceMappingURL=scanBridge.d.ts.map