import type { Header } from "../types/types";
export declare function uploadIon(url: string, headers: Header[], bytes: Uint8Array): Promise<void>;
//# sourceMappingURL=upload.d.ts.map