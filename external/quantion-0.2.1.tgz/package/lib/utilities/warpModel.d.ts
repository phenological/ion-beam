import type { Backend, WarpModelHandle } from "./backend";
import { Metadata } from "./metadata";
import { SampleFile } from "./sampleFile";
import type { PredictedRt, Target } from "../types/types";
import type { ModelEntry } from "../types/internal";
/**
 * A warp model. Make it once with {@link loadWarp} and use it
 * with predictRts for every file.
 */
export declare class WarpModel extends Metadata {
    /** @internal */
    _backend: Backend;
    private _cell;
    private metadata;
    constructor(handle: WarpModelHandle, backend: Backend, metadata: ModelEntry[]);
    get _handle(): WarpModelHandle | null;
    /**
     * predictRts · Models
     *
     * Predict where each target elutes in one sample.
     *
     * @param file - The sample to read, from parse_ion or parse_mzml.
     * @param targets - Targets with mz and reference rt. id and range are optional and not used. Each Target has `id`, `mz`, `rt`, `range`. See {@link https://phenological.github.io/quantion/?language=js#Target | Target}.
     *   Example: `const target: Target = { id: "compound_1", mz: 260.103, rt: 2.383, range: 0.05 };`
     * @returns One PredictedRt per target, in the same order.
     * @see {@link https://phenological.github.io/quantion/?language=js#predict_rts | Documentation}
     */
    predictRts(file: SampleFile, targets: Target[]): Promise<PredictedRt[]>;
    /**
     * calibrate · Models
     *
     * Turn the retention times seen in anchor samples (LTRs, QCs) into targets for predict_rts. Each id gets the median rt over the anchors.
     *
     * @param anchorSamples - Anchor samples.
     * @param targetLists - For each anchor sample, the targets seen in it with their observed rt. Each Target has `id`, `mz`, `rt`, `range`. See {@link https://phenological.github.io/quantion/?language=js#Target | Target}.
     *   Example: `const target: Target = { id: "compound_1", mz: 260.103, rt: 2.383, range: 0.05 };`
     * @returns One Target per id with the median rt.
     * @see {@link https://phenological.github.io/quantion/?language=js#calibrate | Documentation}
     */
    calibrate(anchorSamples: SampleFile[], targetLists: Target[][]): Promise<Target[]>;
    /**
     * dispose · Models
     *
     * Free the memory held by a sample, model or warp model.
     *
     * **Warning:** Not needed in normal use: the library frees a sample, model or warp model by itself once it is no longer used. When processing many samples, dispose each one after using it, so its memory is freed right away instead of piling up.
     * @returns Nothing.
     * @see {@link https://phenological.github.io/quantion/?language=js#dispose | Documentation}
     */
    dispose(): void;
    protected _getMetadata(): ModelEntry[];
    private getHandle;
}
//# sourceMappingURL=warpModel.d.ts.map